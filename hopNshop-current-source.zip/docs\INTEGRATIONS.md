# Integrations and credential requirements

## Supabase

Client: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`. Server-only Edge Function secrets: `SUPABASE_SERVICE_ROLE_KEY` and any provider credentials. Configure email verification, password recovery redirect URLs, Storage buckets and SMTP in Supabase. Allowlist each app origin in Auth URL Configuration; email-link sign-in and password recovery return to the current origin. The account supports password registration/sign-in, password reset and passwordless email-link sign-in. Test these flows against the configured Supabase project's email templates and redirect allowlist.

Migration `202611110007_sourcing_image_storage.sql` creates the private `sourcing-request-media` bucket with a 5 MiB limit and JPEG/PNG/WebP types, then scopes object read/write/delete access to the request owner and admin/editor roles. If the bucket already exists with different settings, the migration stops and requires review; it does not overwrite that bucket's configuration. Verify signed uploads and request ownership with separate customer accounts before launch.

Migration `202611110009_product_media_storage.sql` creates a private `product-media` bucket with the same limits. Only admin/editor roles can upload/delete catalogue assets; customers can obtain short-lived image links only for products that are published. Product images require descriptive alt text.

## M-Pesa Daraja

Required after Safaricom approval: consumer key, consumer secret, short code, passkey, callback URL and production/sandbox environment. Store them only as Edge Function secrets. The callback must be registered with Daraja and verified against the expected request/idempotency key. A payment stays pending until an authorized administrator verifies it; transaction codes entered by customers are not proof.

Manual M-Pesa reference submission is available for resale and sourcing orders after the payment-verification migration is applied. Customers enter a transaction code, payer name and exact order total; an administrator or finance user must confirm these against the official M-Pesa statement before the order advances. Configure and publish verified payment instructions separately before asking customers to pay. Manual submissions are untrusted claims, not payment evidence.

## Affiliate programmes

Each partner requires documented approval, tracking rules, geographic eligibility, commission terms, permitted product imagery and an approved tracking URL/feed/API. The system has partner/link/click/reconciliation tables, but no partnership or rate is asserted by this repository.

## Notifications

Email, WhatsApp and SMS providers are optional adapters. Configure provider credentials and templates only after consent, sender verification and delivery testing. Until configured, admins can use in-app status updates.

## Marketplace sources

Jumia, Amazon, Alibaba, SHEIN, Kilimall and other sources require permitted APIs, affiliate feeds or manual review. The URL function rejects unsafe URLs and never bypasses CAPTCHA, login restrictions, anti-bot controls or robots policies.
