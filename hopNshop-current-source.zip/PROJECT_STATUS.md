﻿# hopNshop project status and specification checklist

Updated: 2026-11-11 (Africa/Nairobi)

## Status key

- **Complete and verified** — implemented and exercised by an applicable automated or manual check.
- **Implemented but unverified** — code/schema exists, but live integration or acceptance evidence is unavailable.
- **Partially implemented** — some of the requirement exists; important parts remain.
- **Not implemented** — no functioning implementation found.
- **Blocked by external credentials or approval** — cannot safely activate until an external credential, asset, permission, or approval is supplied. Internal implementation work may still be possible.

## Preservation and development state

- This is the existing Ionic React/Vite project. No files were deleted, the project was not rebuilt, and no environment values were copied into this status file.
- This workspace has no `.git` directory. Git history, `git status`, attribution of earlier edits, and safe Git checkpoints are unavailable. No destructive Git command was run. Establish a repository/checkpoint from the authoritative project source when `.git` is restored.
- The supplied specification was found at the user-provided attachment path and is now the governing checklist below. `hopNshop-source.zip` contains the earlier scaffold, not this specification or newer workflows.
- `.env` was inspected only for whether settings are present: Supabase URL is set; anon key is absent. No secret value is recorded. Supabase-backed behavior remains unverified.
- Existing stack: Ionic React 8, React 19, TypeScript, Vite 7, Supabase JS, Capacitor 7, PostgreSQL/RLS migrations. `package.json`, lockfile and installed dependencies are present.

## Implemented in this continuation

- Added password registration, password sign-in, password-reset email and recovery-password update to the existing Supabase email-link sign-in modal in `src/App.tsx`.
- Added customer wishlist save/remove controls and wishlist view. Replaced the nonfunctional newsletter form with a clear message because no delivery provider is configured.
- Added guidance on Auth URL allowlisting and email-template setup to `docs/INTEGRATIONS.md`.
- Added `supabase/migrations/202611110003_security_hardening.sql`: enables RLS on previously uncovered tables; narrows staff access by role; removes customer ability to change sourcing request status; and restricts data access for orders, addresses, payments, notifications and support.
- Added `supabase/migrations/202611110004_manual_payment_verification.sql` plus `AdminPaymentQueue.tsx`: customers submit M-Pesa reference/payer/amount against an order; only admin/finance can verify or reject. Server checks ownership, amount, duplicate references and state. Customer submissions stay pending and never count as proof.
- Added `supabase/migrations/202611110005_order_fulfilment_workflow.sql` plus `AdminOrderQueue.tsx`: admin/fulfilment roles advance permitted order states with a customer update and courier/tracking details; the database checks transitions, writes an audit record and customer-visible event. Customers see the order timeline.
- Added `supabase/migrations/202611110006_sourcing_product_name.sql`; customers can include a bounded product name with a request and both customer/admin views display it.
- Added `supabase/migrations/202611110007_sourcing_image_storage.sql`: creates a private 5 MiB JPEG/PNG/WebP bucket, refuses unexpected pre-existing bucket settings, and scopes object access to the request owner and admin/editor. Sourcing form uploads images and the admin queue uses signed URLs.
- Added admin/editor catalogue create/edit/publish controls with client/server publication checks, scoped private product-media storage, descriptive alt-text uploads, published-product signed galleries and product detail modals. Added variant creation/removal, customer option selection and variant-aware server-side order price/availability validation in migration 202611110010_product_variant_orders.sql. Added admin category creation and publication controls; categories populate product editor and storefront filters. Added curated collection/product membership with role-gated management, RLS migration 202611110011_collection_products.sql and published collection storefront cards. Added admin supplier verification and affiliate programme records/status controls.
- Added category, brand, availability, currency-aware price filters, sorting and load-more pagination to product discovery; added domain tests for publication rules and combined/safe-currency filtering.
- Created `hopNshop-current-source.zip` as a preservation snapshot containing source, docs, migrations, tests and config templates, excluding `.env`, `.git`, `node_modules`, `dist` and the earlier scaffold archive.
- These paths compile, but Auth, SQL and Storage have not been exercised against Supabase because the anon key/database are unavailable. Image upload is wired but cannot be used until the migrations and verified private bucket exist in the configured project.

## Requirement checklist

### 1. Business overview and three business models

- [ ] **Partially implemented** — premium curated discovery, reliable information, transparent sourcing, comparisons, collections, bundles, deals, video discovery and local fulfilment: only the editorial-style shell and manual sourcing concept exist; most capabilities below are missing.
- [ ] **Partially implemented** — Affiliate commerce: products can link to a configured external tracking URL; tracking/campaign attribution, commission lifecycle and reconciliation are not wired.
- [ ] **Implemented but unverified** — Affiliate purchases remain external and are not created as hopNshop orders; frontend purchase action opens the retailer. Disclosures and retailer-specific delivery/returns explanations are incomplete.
- [ ] **Partially implemented** — Resale/pre-order: published products can be added to a cart and an authenticated customer can create an order through a database RPC. Customer M-Pesa details can be submitted for manual review, but no payment is taken or confirmed automatically; procurement and order updates remain unverified.
- [ ] **Blocked by external credentials or approval** — Resale supplier permissions, blind-shipping permissions and approved sourcing relationships are not evidenced; verify before selling or procuring.
- [ ] **Partially implemented** — Personal sourcing: customer can submit URL, optional product name, reference image, variant, quantity and notes; staff can review images and prepare a KES quote; customer can accept it. Cancellation/rejection/revisions, notifications and procurement execution remain missing. Manual payment review and staff fulfilment updates exist but are unverified.

### 2. Technology architecture

- [x] **Complete and verified** — Existing frontend uses Ionic React, TypeScript and Vite; TypeScript check passes and production web bundle builds.
- [ ] **Implemented but unverified** — React Router, reusable components, responsive CSS and Capacitor configuration exist; navigation is currently a single-page shell, reusable design-system coverage is limited, and device packaging is not tested.
- [ ] **Partially implemented** — Supabase PostgreSQL/Auth/RLS/Edge Function architecture and migrations exist; database migrations and RLS have not been applied or integration-tested against a Supabase project.
- [ ] **Implemented but unverified** — Supabase Storage bucket/policies and authenticated sourcing image uploads exist; no live bucket/database test has run. Netlify/Vercel deployment configuration is absent.
- [ ] **Partially implemented** — Android app identity is configured in Capacitor; no generated Android project, APK/AAB pipeline or iOS validation exists. No Android Studio or emulator was installed.
- [ ] **Not implemented** — Git/GitHub checkpointing is unavailable in the current folder because `.git` is absent.

### 3. Design system and brand

- [ ] **Blocked by external credentials or approval** — Specification says the official logo was supplied, but no `brand-assets` directory or logo file exists in the inspected workspace/archive. Integrate the original asset when it is made available; do not redraw or substitute it.
- [ ] **Partially implemented** — Current responsive storefront has a coherent palette, type choices, hero, product cards, dialogs, loading/empty/error states and mobile CSS; it is not yet a complete premium design system.
- [ ] **Not implemented** — Reusable tables, drawers, badges, notification/confirmation components and refined motion system.
- [ ] **Partially implemented** — Desktop/mobile browser layout has responsive breakpoints; tablet and Android-device QA has not been performed.

### 4. Customer storefront and product discovery

- [ ] **Partially implemented** — Homepage has branded navigation, text search, sourcing promotion and footer; category/brand/availability/currency-aware price filters, sorting and load-more pagination use live catalogue rows. Published curated collections now appear on the storefront. Real trending/new/deal sections, bundles and editorial content remain absent.
- [ ] **Implemented but unverified** — Product search matches name/description/brand; category, brand, availability and currency-aware price filtering, sorting and client-side load-more pagination exist. No large-catalogue performance or live data test has run.
- [ ] **Partially implemented** — Wishlist save/remove and account display are implemented but not integration-tested. Related products, recently viewed products and comparison are absent.
- [ ] **Partially implemented** — Product cards link to a detail modal with verified fields, estimated costs, source and business-model disclosure; published product image galleries are shown. Variant options are now shown and selectable, including variant-specific cart totals and order snapshots; live catalogue and order RPC behavior remains unverified. Full specification details and shipping/fulfilment information remain missing.
- [ ] **Implemented but unverified** — Affiliate action is differentiated from internal resale order creation; approved disclosure copy and customer-facing handling of retailer delivery/returns/support are incomplete.
- [ ] **Implemented but unverified** — Admin-curated collections with product membership and storefront presentation exist; comparison workflow, bundles and evidenced bundle savings are absent.

### 5. Customer accounts and authentication

- [ ] **Implemented but unverified** — Supabase email/password registration and sign-in, passwordless email-link sign-in, logout, password reset email and recovery password update are now wired in `src/App.tsx`; live email/Auth behavior needs Supabase credentials, redirect allowlisting and provider testing.
- [ ] **Partially implemented** — Session state is observed and customer data uses authenticated user identity; protected routes, account security controls and auth component tests are absent.
- [ ] **Partially implemented** — Account modal displays orders, sourcing requests, quotations, wishlist and payment history and allows quote acceptance; profile editing, saved-address management, notifications, support and account-data deletion/export are absent. Live integration is unverified.
- [ ] **Implemented but unverified** — Customer-specific reads are scoped by user ID and RLS policies; cross-account isolation has not been verified against a live database.

### 6. Product catalogue and management

- [ ] **Partially implemented** — Database has products, variants, media, sources, currency, local/source price fields, shipping/duties estimates, margin, availability, publication status and verification timestamp; retailer, richer specifications, supplier/source-price history, independent freshness timestamps and fulfilment/disclosure fields are incomplete.
- [ ] **Implemented but unverified** — Product draft/review/published/archived states, admin/editor RLS, create/edit/publish form and database publication trigger exist; no live DB/role test has run.
- [ ] **Partially implemented** — Admin/editor can create/edit/publish/archive products, add/remove variants and manage private gallery images with alt text. Bulk management, editing existing variants, image ordering, price history and live RLS/Storage testing remain. Category creation/publication and collection curation controls exist but are unverified.
- [ ] **Implemented but unverified** — Storefront reads only published catalogue rows and does not fabricate reviews, ratings, sales figures or availability; no live catalogue test has run.

### 7. Product sourcing engine

- [ ] **Implemented but unverified** — Request accepts HTTPS public URL, optional product name, private reference image (JPEG/PNG/WebP up to 5 MiB), variant, quantity and notes; live Storage/RLS behavior is untested. Multiple products per request, cancellation and customer/internal notes separation are absent.
- [ ] **Implemented but unverified** — Staff queue and quote preparation are present; queue, statuses and permissions depend on unapplied migrations/credentials.
- [ ] **Partially implemented** — Request → review → quote → accept → awaiting-payment → manual payment review → staff fulfilment update exists in code; live workflow verification, notifications, reject/revise and procurement execution are missing.
- [ ] **Partially implemented** — URL validation rejects common private/localhost ranges and does not scrape; robust DNS rebinding/unsafe redirect defenses are not implemented. Current validator is not a safe arbitrary-URL fetcher.
- [ ] **Blocked by external credentials or approval** — Automatic marketplace extraction is not configured; only authorised APIs/feeds and manual review are supported by policy.
- [ ] **Implemented but unverified** — Private request image bucket, client-side size/type validation and owner/admin/editor object policies exist; live object ownership, signed URL and upload tests are pending.

### 8. Quotation and pricing engine

- [ ] **Partially implemented** — Admin/editor form accepts item price, shipping, duties, taxes, service fee, flat markup, discount, delivery estimate and expiry; source currency/exchange-rate conversion, insurance, customs/local delivery line items and configurable margins are missing.
- [ ] **Implemented but unverified** — SQL RPC validates quote amounts/expiry, snapshots quote rows and writes audit data; migration and DB behavior have not been executed.
- [ ] **Partially implemented** — Customer sees quote total, item lines, expiry and delivery window; a transparent cost breakdown and estimates-versus-confirmed/actual labels are missing.
- [ ] **Not implemented** — Historical exchange-rate capture and quotation revisions/snapshots beyond the current quote record.

### 9. Payments

- [ ] **Blocked by external credentials or approval** — Daraja STK Push/callback registration and production/sandbox credentials are absent; no payment initiation adapter or UI exists.
- [ ] **Partially implemented** — Payment table and callback scaffold exist; callback currently does not authenticate provider origin or verify amount/order association and cannot be treated as payment proof.
- [ ] **Implemented but unverified** — Customer manual M-Pesa reference/payer/amount submission and admin/finance verification/rejection UI/RPC exist; the migration is unapplied and live role/statement checks are unavailable. Publish verified payment instructions before inviting payment.
- [ ] **Partially implemented** — Payment rows now support unique manual references and reviewed-by metadata; reconciliation, refund workflow, STK callback verification and payment integration tests are absent.
- [x] **Complete and verified** — Affiliate purchases do not use hopNshop payment/order creation in the implemented storefront.

### 10. Order management and fulfilment

- [ ] **Implemented but unverified** — Order status enum covers the specified lifecycle, and resale/sourcing orders can be created through RPCs; no live transaction verification has run.
- [ ] **Implemented but unverified** — Customer can see order number, items, total, payment history and customer-visible fulfilment timeline with courier/tracking details; live database testing is pending.
- [ ] **Implemented but unverified** — Admin/fulfilment order queue and server-validated transition/update workflow exist; full order-management and refund processing are absent.
- [ ] **Partially implemented** — Staff RPC records factual customer-visible updates and tracking metadata; live role/RLS testing and automatic customer notifications are absent.

### 11. Supplier management

- [ ] **Partially implemented** — Supplier/product tables store name, country, type, marketplace, verification status, notes, MOQ and lead time; contacts, categories, samples, return/payment terms, shipping permissions and reliability history are missing.
- [ ] **Implemented but unverified** — Supplier creation, verification status and evidence notes are available to admins; contact, sample, terms and supplier performance reporting remain absent.
- [ ] **Blocked by external credentials or approval** — Supplier verification and resale/fulfilment permissions require external evidence and approval.

### 12. Administrative dashboard and roles

- [ ] **Partially implemented** — Admin/editor product catalogue, sourcing, payment verification, order/fulfilment queues, collections and supplier/affiliate programme records exist; overview metrics and customer, refunds, support, reports, notifications and settings modules are absent.
- [ ] **Not implemented** — Real database-backed admin overview metrics.
- [ ] **Partially implemented** — Roles exist for customer, admin, editor, fulfilment and finance; super-admin and operations-staff role distinctions/permissions are incomplete.
- [ ] **Implemented but unverified** — Admin/editor quote RPC checks roles server-side; RLS policies now limit selected management data, but complete least-privilege review and live role tests are pending.
- [ ] **Implemented but unverified** — No self-service admin role assignment was found; role provisioning and audit process still require controlled Supabase operations.

### 13. Financial reporting

- [ ] **Partially implemented** — Orders, payments, refunds, affiliate events and operating expense tables exist; records and definitions for GMV, revenue, commissions, costs, fees, chargebacks and margins are incomplete.
- [ ] **Not implemented** — Reports UI, date/model/transaction filters, CSV exports, summary and detailed reports.
- [ ] **Not implemented** — Explicit estimate-versus-confirmed financial state and contribution/net-profit calculation from verified transactions.

### 14. Affiliate management

- [ ] **Implemented but unverified** — Partner status/disclosure/rate/terms records have an admin management UI; affiliate link administration, click endpoint, campaign attribution and commission reconciliation are absent.
- [ ] **Implemented but unverified** — No actual partner or rate is claimed in the repository; affiliate links are used only when present on a published product.
- [ ] **Blocked by external credentials or approval** — Partner programme approval, geographic eligibility, attribution rules and payout requirements must be verified before activation.

### 15. Product discovery automation

- [ ] **Partially implemented** — Published products load from Supabase; approved feed/API ingestion, metadata imports, freshness tracking, tagging and category suggestions are absent.
- [ ] **Partially implemented** — Manual product create/edit/publish and media controls exist; approved-feed discovery queue, freshness checks, metadata imports and automated SEO metadata are absent.
- [ ] **Partially implemented** — Publication state exists and manual create/edit/publish controls are present; approved feeds, freshness tracking, metadata and discovery queues remain absent.
- [ ] **Not implemented** — AI-assisted product descriptions; AI must remain optional and is not configured.

### 16. Notifications and customer support

- [ ] **Partially implemented** — Notification and support-case tables exist; customer/admin UI, in-app delivery and status workflows are absent.
- [ ] **Blocked by external credentials or approval** — Email/WhatsApp/SMS providers and consent/sender configuration are not supplied.
- [ ] **Not implemented** — Event-driven customer notifications and manual support fallback workflow.

### 17. Android application

- [ ] **Partially implemented** — Capacitor app ID/name/webDir and Android scheme are set; no generated Android project or build pipeline exists.
- [ ] **Blocked by external credentials or approval** — Official icon/splash source assets are absent.
- [ ] **Partially implemented** — CSS supports mobile viewport and safe-area viewport setting exists; keyboard handling, deep links, share, camera/photo picker, push notification and offline catalogue cache are absent.
- [ ] **Not implemented** — Stale-cache labels and offline-action handling.
- [ ] **Complete and verified** — No Android Studio or emulator has been installed as requested.

### 18. Database architecture

- [ ] **Partially implemented** — Core tables, relationships, timestamps, some checks/indexes and business/status enums exist; several suggested entities/fields and constraints are absent.
- [ ] **Implemented but unverified** — New RLS hardening migration addresses previously uncovered tables and removes customer ability to alter sourcing request status; migrations have not been applied to a Supabase project or reviewed by a live policy test.
- [ ] **Partially implemented** — Core customer isolation and selected staff permissions have policies; full least-privilege coverage, storage-object policies and cross-account tests remain.
- [x] **Complete and verified** — Seed is explicitly marked demo-only and unpublished.
- [x] **Complete and verified** — Frontend uses the anon client key and no service-role credential is in Vite code; server-only secret requirements are documented.

### 19. Security and privacy

- [ ] **Implemented but unverified** — Supabase Auth/RLS and server-side RPC validation exist, with additional hardening migration added; live RLS and auth attack-surface tests are pending.
- [ ] **Partially implemented** — Input validation and HTTPS/private-IP URL checks exist; robust SSRF/DNS/re-direct protection, rate limiting and abuse protection are absent.
- [ ] **Partially implemented** — Sourcing and product media uploads validate type/size and use scoped Storage policies; storage tests, protected route layer, full audit coverage and user privacy/data export/deletion workflow remain absent.
- [ ] **Partially implemented** — Safe user-facing error messages and no hardcoded app credentials were found; some logs include backend error messages, and production logging/privacy review is pending.
- [ ] **Blocked by external credentials or approval** — Data protection, consumer, tax/import and payment-provider legal/regulatory review is outside the repository and not evidenced.
- [ ] **Not implemented** — Editable privacy, terms, returns/refunds, shipping/delivery and affiliate disclosure policy documents/pages. Footer currently has non-linked labels.

### 20. SEO and marketing

- [ ] **Partially implemented** — Root title/description/canonical, robots and sitemap exist; per-product/category/collection/editorial metadata and SEO routes are absent.
- [ ] **Not implemented** — Open Graph/social sharing, structured product data and shareable product/collection pages.
- [ ] **Partially implemented** — Search-friendly root and source anchor exist; no real category/product/collection routes.

### 21. Testing and QA

- [x] **Complete and verified** — TypeScript check passes.
- [x] **Complete and verified** — Current domain suite passes: 1 file, 15 tests (quote math, URL/request/image validation, resale eligibility, quote/order/payment validation, publication rules, discovery filters/sorts, order transitions). Variant/order and category RPC behavior is not integration-tested.
- [x] **Complete and verified** — Production web bundle builds with Vite runner config loader.
- [ ] **Not implemented** — Component tests, auth/payment/role/RLS/product-publishing/freshness tests and full end-to-end scenarios.
- [ ] **Partially implemented** — Sourcing → quote → accept → manual payment review → staff fulfilment elements exist; procurement execution, refund/cancel, affiliate click verification and reporting/export scenarios are not implemented.
- [ ] **Partially implemented** — No fabricated reviews, ratings, production metrics or availability were found in current storefront; full catalogue/product acceptance QA is absent.
- [ ] **Partially implemented** — The plain `npm.cmd test` and `npm.cmd run build` config-bundling path hits a restricted parent-directory access error in this OneDrive sandbox. `npm.cmd test -- --configLoader runner` and `npm.cmd exec vite build -- --configLoader runner` pass.

### 22. Development execution rules

- [x] **Complete and verified** — Existing implementation has been preserved; no destructive Git command or Android Studio/emulator installation was performed.
- [ ] **Partially implemented** — Documentation and config templates exist; migration/Auth integration verification needs credentials.
- [ ] **Not implemented** — Git checkpoints cannot be maintained until repository metadata is restored.

### 23. Deliverables

- [x] **Complete and verified** — Source code, web application, Supabase SQL migrations, demo seed, environment example, README, architecture/integration/admin/security documentation and project status exist.
- [ ] **Partially implemented** — Authentication, storefront, sourcing/quotation, customer account, admin sourcing/payment/order workflows and catalogue create/edit/publish are present; full product, supplier, finance, notification and support systems are incomplete.
- [ ] **Partially implemented** — Capacitor configuration and Android build instructions exist; Android project and APK/AAB are not available.
- [ ] **Partially implemented** — A current source ZIP (hopNshop-current-source.zip) excludes secrets/build caches and Netlify/Vercel deployment instructions are documented; automated deployment pipeline is absent.
- [ ] **Complete and verified** — Known limitations and outstanding requirements are documented in this file.

### 24. Final acceptance criteria

- [x] **Complete and verified** — Web TypeScript check, domain tests and production build pass using the documented runner workaround.
- [ ] **Partially implemented** — Responsive storefront exists; polished full premium discovery and mobile/device QA remain.
- [ ] **Blocked by external credentials or approval** — Supplied official logo is not present in workspace.
- [ ] **Implemented but unverified** — Authentication paths are wired, but Supabase email settings/redirects and live account workflows are not tested.
- [ ] **Implemented but unverified** — SQL migrations and selected RLS exist, including security hardening; no live database has applied/tested them.
- [ ] **Partially implemented** — Customer accounts, wishlist, sourcing, quote creation/acceptance, manual payment review, staff fulfilment and admin/editor catalogue, variant and product media controls exist; live product detail/gallery/order variant and collection flows, affiliate tracking, procurement, refunds and full support remain incomplete.
- [ ] **Partially implemented** — Affiliate link separation exists; approved program/disclosure/tracking and management flows are incomplete.
- [ ] **Partially implemented** — Admin sourcing controls exist; full role-separated admin controls and real-data reporting are missing.
- [ ] **Partially implemented** — Android identity/configuration exists; Android packaging and device acceptance are incomplete.
- [ ] **Not implemented** — Automated component, integration, security and end-to-end suites are absent.
- [ ] **Blocked by external credentials or approval** — Production payment, marketplace, supplier and regulatory readiness require external credentials/approvals.

## Verification in this continuation

- `npm.cmd run lint` — passed (`tsc --noEmit`) after collection and supplier/affiliate management changes.
- `npm.cmd test -- --configLoader runner` — passed: 1 test file, 15 tests.
- `npm.cmd exec vite build -- --configLoader runner` — passed. Existing warnings: main bundle exceeds 500 kB and Rollup removes upstream Zod pure-annotation comments.
- SQL migrations 003–011 — reviewed statically only; no `psql`, Supabase CLI or database credentials were available, so they have not been applied or executed.
- Live Auth — not tested; Supabase anon key is absent.
- Git — unavailable because `.git` is absent.

## Highest-priority next task

Add affiliate link administration with campaign attribution and supplier product/terms detail. Then address customer support, reporting, notification workflows and full Android delivery within existing constraints. Before release, restore `.git`, apply migrations 003–011 in a non-production Supabase project, verify bucket/RLS policies, and run RLS/Auth/payment/fulfilment integration tests. Keep STK Push disabled until Daraja credentials, callback registration and provider validation are available.






