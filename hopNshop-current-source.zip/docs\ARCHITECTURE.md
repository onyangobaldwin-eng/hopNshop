# Architecture

The app is a Vite-built Ionic React client shared by web and Capacitor Android. `src/lib/domain.ts` contains pure business rules that can be reused by UI and server-side tests. Supabase PostgreSQL is the system of record; RLS policies enforce customer isolation and administrator access. The storefront reads only published products. Sourcing requests are written only for an authenticated customer; the client sends a Supabase email sign-in link when no session exists.

Business models remain explicit in `products.business_model`, `orders.business_model`, and the UI/integration boundaries: affiliate clicks leave hopNshop and must use the approved tracking URL; resale and sourcing orders remain hopNshop workflows. The current storefront does not yet implement resale checkout or the full sourcing quotation/order workflow.

Timestamped migrations cover profiles, roles, catalogue, sources, suppliers, affiliate links/clicks, sourcing, quotations, orders, payments, refunds, fulfilment events, wishlists, notifications, support, editorial content, expenses, exchange rates, integrations and audit logs. Later migrations harden RLS, add manual payment submission/review RPCs, and add staff-controlled order transition RPCs with customer-visible fulfilment events. Apply migrations in filename order. Add future schema through timestamped migrations.

Production catalogue content is managed through Supabase; no catalogue is hardcoded in the client. Add repositories around Supabase queries as pages are expanded. Keep service-role operations inside Edge Functions only.
