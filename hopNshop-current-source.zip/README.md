# hopNshop

hopNshop is an Ionic React commerce and product-sourcing application for Kenya. It supports curated affiliate discovery, hopNshop-owned sales/pre-orders, and customer sourcing requests with quotations.

## Local development

1. Install Node.js 22+ and npm on Windows. If PowerShell blocks `npm.ps1`, run npm commands as `npm.cmd`.
2. Copy `.env.example` to `.env` and add a Supabase project URL and anon key.
3. Run `npm.cmd install` and `npm.cmd run dev` in PowerShell.
4. Apply every timestamped migration in `supabase/migrations/` in filename order with the Supabase CLI or SQL editor. This includes customer workflows, admin quotations, security hardening, manual payment verification and fulfilment updates. `supabase/seed.sql` is demo-only and intentionally unpublished.

The storefront loads published products from Supabase and displays an honest empty or error state rather than fabricated catalogue data. Customers can register/sign in with a password or use an email link, and can submit a M-Pesa transaction reference for administrator verification against an order total. Manual details are not payment proof; only submit after receiving verified hopNshop payment instructions. STK Push is not configured. Without a configured Supabase URL and anon key, catalogue and account workflows remain unavailable.

## Verification

`npm.cmd run lint` runs the TypeScript check, `npm.cmd test` runs domain tests, and `npm.cmd run build` produces the Vite web build.

## Capacitor Android

After installing Android Studio, the Android SDK, JDK 21 and Gradle tooling:

```powershell
npm.cmd install
npm.cmd run build
npx.cmd cap add android
npx.cmd cap sync android
npx.cmd cap open android
```

Build an APK/AAB from Android Studio after configuring the signing key in the local Gradle properties. Never commit `android/local.properties`, signing keys or passwords.

## Supabase Edge Functions

- `validate-source` validates a URL and returns a manual-review-required response; it does not persist or enqueue requests and deliberately does not scrape arbitrary URLs. The storefront's authenticated request form writes customer submissions to `sourcing_requests`.
- `mpesa-callback` persists provider callbacks idempotently and never treats a frontend message as payment proof.

Deploy functions with the Supabase CLI and set server-only secrets using `supabase secrets set`. Required M-Pesa secrets are listed in [docs/INTEGRATIONS.md](docs/INTEGRATIONS.md).

## Documents

- [Architecture](docs/ARCHITECTURE.md)
- [Integrations and credentials](docs/INTEGRATIONS.md)
- [Administrator guide](docs/ADMIN_GUIDE.md)
- [Security checklist](docs/SECURITY.md)
- [Web deployment guide](docs/DEPLOYMENT.md)
- [PROJECT_STATUS.md](PROJECT_STATUS.md)
