# Administrator guide

Assign roles directly in a controlled Supabase administrative workflow; users cannot self-register as admins. Review and verify source data before publishing products. Set `publication_status=published` only when source URL, price freshness, availability, fulfilment model and disclosures are recorded.

Admin and editor roles can create/edit products in the account catalogue panel. Publishing requires the editor to confirm the source, price, availability, disclosure and supplier/program permissions. Add descriptive-alt-text images through the product image manager; the private bucket exposes short-lived URLs only for published products. Keep draft images inside staff review.

For sourcing: review the submitted link and any private reference image, record permitted source details, calculate estimated item/shipping/duty/tax/service/markup amounts, publish a quotation with expiry and delivery window, then wait for acceptance and verified payment before procurement. Record every fulfilment update as a customer-visible event only when it is real.

Affiliate products redirect to the retailer and must not create hopNshop payment orders. Use financial reports to distinguish customer order value, procurement costs, commissions, refunds and operating expenses.

For manual M-Pesa submissions, verify the transaction reference, payer, amount and recipient against the official statement before using the finance queue to confirm it. Customer-entered details remain pending and do not prove payment. After verification, fulfilment staff can progress the order one allowed step at a time and record a factual customer-visible update, courier and tracking reference. Do not record dispatch or delivery before it occurs. STK Push and automatic refund settlement are not configured.
