# Administrator guide

Assign roles directly in a controlled Supabase administrative workflow; users cannot self-register as admins. Review and verify source data before publishing products. Set `publication_status=published` only when source URL, price freshness, availability, fulfilment model and disclosures are recorded.

For sourcing: review the submitted link, record permitted source details, calculate estimated item/shipping/duty/tax/service/markup amounts, publish a quotation with expiry and delivery window, then wait for acceptance and verified payment before procurement. Record every fulfilment update as a customer-visible event only when it is real.

Affiliate products redirect to the retailer and must not create hopNshop payment orders. Use financial reports to distinguish customer order value, procurement costs, commissions, refunds and operating expenses.
