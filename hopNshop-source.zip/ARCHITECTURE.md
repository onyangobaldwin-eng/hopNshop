# Architecture

The app is a Vite-built Ionic React client shared by web and Capacitor Android. `src/lib/domain.ts` contains pure business rules that can be reused by UI and server-side tests. Supabase PostgreSQL is the system of record; RLS policies enforce customer isolation and administrator access.

Business models remain explicit in `products.business_model`, `orders.business_model`, and the UI/integration boundaries: affiliate clicks leave hopNshop, while resale and sourcing orders remain in the hopNshop order workflow.

The initial schema covers profiles, roles, catalogue, sources, suppliers, affiliate links/clicks, sourcing, quotations, orders, payments, refunds, fulfilment events, wishlists, notifications, support, editorial content, expenses, exchange rates, integrations and audit logs. Add future tables through timestamped migrations.

Production catalogue content is managed through Supabase; no catalogue is hardcoded in the client. Add repositories around Supabase queries as pages are expanded. Keep service-role operations inside Edge Functions only.
