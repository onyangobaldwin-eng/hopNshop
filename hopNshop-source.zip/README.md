# hopNshop

hopNshop is an Ionic React commerce and product-sourcing application for Kenya. It supports curated affiliate discovery, hopNshop-owned sales/pre-orders, and customer sourcing requests with quotations.

## Local development

1. Install Node.js 22+ and npm on Windows.
2. Copy `.env.example` to `.env` and add a Supabase project URL and anon key.
3. Run `npm install` and `npm run dev`.
4. Apply `supabase/migrations/202611100001_initial.sql` with the Supabase CLI or SQL editor. `supabase/seed.sql` is demo-only and intentionally unpublished.

The storefront is safe to run without Supabase: it renders a real empty catalogue state and the sourcing dialog explains that secure submission requires the backend. It does not fabricate products, reviews, prices, stock, orders or payment confirmations.

## Verification

`npm run lint` runs the TypeScript check, `npm test` runs domain tests, and `npm run build` produces the Vite web build. This workspace currently has no Node.js executable, so these commands are documented but could not be executed in this environment.

## Capacitor Android

After installing Android Studio, the Android SDK, JDK 21 and Gradle tooling:

```powershell
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

Build an APK/AAB from Android Studio after configuring the signing key in the local Gradle properties. Never commit `android/local.properties`, signing keys or passwords.

## Supabase Edge Functions

- `validate-source` performs secure URL validation and queues manual review; it deliberately does not scrape arbitrary URLs.
- `mpesa-callback` persists provider callbacks idempotently and never treats a frontend message as payment proof.

Deploy functions with the Supabase CLI and set server-only secrets using `supabase secrets set`. Required M-Pesa secrets are listed in [docs/INTEGRATIONS.md](docs/INTEGRATIONS.md).

## Documents

- [Architecture](docs/ARCHITECTURE.md)
- [Integrations and credentials](docs/INTEGRATIONS.md)
- [Administrator guide](docs/ADMIN_GUIDE.md)
- [Security checklist](docs/SECURITY.md)
- [PROJECT_STATUS.md](PROJECT_STATUS.md)
