import { z } from 'zod';

export type BusinessModel = 'affiliate' | 'resale' | 'sourcing';
export type ProductAvailability = 'affiliate' | 'local_inventory' | 'pre_order' | 'sourcing_only';
export type OrderStatus = 'awaiting_payment' | 'payment_verification' | 'payment_confirmed' | 'procurement_approved' | 'ordered_from_supplier' | 'supplier_processing' | 'dispatched' | 'international_transit' | 'customs_processing' | 'local_courier' | 'ready_for_collection' | 'delivered' | 'cancelled' | 'refund_pending' | 'refunded' | 'exception';

export const sourcingRequestSchema = z.object({
  productUrl: z.string().url().max(2000), quantity: z.number().int().min(1).max(100), variant: z.string().max(200).optional(), notes: z.string().max(2000).optional()
});

export interface Product { id: string; name: string; slug: string; description: string; brand?: string; category?: string; availability: ProductAvailability; businessModel: BusinessModel; localPrice?: number; currency: string; imageUrl?: string; sourceUrl?: string; publishedAt?: string; verifiedAt?: string; }
export interface QuoteLine { description: string; quantity: number; unitAmount: number; }
export interface QuoteInput { lines: QuoteLine[]; shipping: number; duties: number; taxes: number; serviceFee: number; markupRate: number; discount: number; }
export interface QuoteTotals { subtotal: number; markup: number; total: number; }

export function calculateQuote(input: QuoteInput): QuoteTotals {
  const subtotal = input.lines.reduce((sum, line) => sum + line.quantity * line.unitAmount, 0) + input.shipping + input.duties + input.taxes + input.serviceFee;
  const markup = Math.max(0, subtotal * input.markupRate);
  return { subtotal, markup, total: Math.max(0, subtotal + markup - input.discount) };
}

export function isValidPublicProductUrl(raw: string): boolean {
  try {
    const url = new URL(raw);
    if (url.protocol !== 'https:') return false;
    const host = url.hostname.toLowerCase();
    if (host === 'localhost' || host.endsWith('.localhost') || host === '::1' || /^127\./.test(host) || /^10\./.test(host) || /^192\.168\./.test(host) || /^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return false;
    return host.includes('.') && !url.username && !url.password;
  } catch { return false; }
}

export const ORDER_STATUS_FLOW: OrderStatus[] = ['awaiting_payment', 'payment_verification', 'payment_confirmed', 'procurement_approved', 'ordered_from_supplier', 'supplier_processing', 'dispatched', 'international_transit', 'customs_processing', 'local_courier', 'ready_for_collection', 'delivered'];

export function canTransitionOrder(from: OrderStatus, to: OrderStatus): boolean {
  if (to === 'cancelled' || to === 'exception') return !['delivered', 'refunded'].includes(from);
  if (to === 'refund_pending') return ['payment_confirmed', 'delivered', 'exception'].includes(from);
  if (to === 'refunded') return from === 'refund_pending';
  return ORDER_STATUS_FLOW.indexOf(to) === ORDER_STATUS_FLOW.indexOf(from) + 1;
}
