# Integrations and credential requirements

## Supabase

Client: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`. Server-only Edge Function secrets: `SUPABASE_SERVICE_ROLE_KEY` and any provider credentials. Configure email verification, password recovery redirect URLs, Storage buckets and SMTP in Supabase.

## M-Pesa Daraja

Required after Safaricom approval: consumer key, consumer secret, short code, passkey, callback URL and production/sandbox environment. Store them only as Edge Function secrets. The callback must be registered with Daraja and verified against the expected request/idempotency key. A payment stays pending until an authorized administrator verifies it; transaction codes entered by customers are not proof.

## Affiliate programmes

Each partner requires documented approval, tracking rules, geographic eligibility, commission terms, permitted product imagery and an approved tracking URL/feed/API. The system has partner/link/click/reconciliation tables, but no partnership or rate is asserted by this repository.

## Notifications

Email, WhatsApp and SMS providers are optional adapters. Configure provider credentials and templates only after consent, sender verification and delivery testing. Until configured, admins can use in-app status updates.

## Marketplace sources

Jumia, Amazon, Alibaba, SHEIN, Kilimall and other sources require permitted APIs, affiliate feeds or manual review. The URL function rejects unsafe URLs and never bypasses CAPTCHA, login restrictions, anti-bot controls or robots policies.
