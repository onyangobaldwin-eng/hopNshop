import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'ke.hopnshop.app', appName: 'hopNshop', webDir: 'dist', bundledWebRuntime: false, server: { androidScheme: 'https' } };
export default config;
