import { useEffect, useMemo, useState } from 'react';
import { IonApp, IonContent, IonIcon, IonPage } from '@ionic/react';
import { bagHandleOutline, heartOutline, menuOutline, searchOutline, shieldCheckmarkOutline, sparklesOutline, arrowForwardOutline } from 'ionicons/icons';
import { isSupabaseConfigured } from './lib/supabase';
import type { Product } from './lib/domain';

const nav = ['Discover', 'Collections', 'Source a product', 'Buying guides'];
const emptyProducts: Product[] = [];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [products] = useState<Product[]>(emptyProducts);
  const [sourcingOpen, setSourcingOpen] = useState(false);
  const filtered = useMemo(() => products.filter(p => p.name.toLowerCase().includes(search.toLowerCase())), [products, search]);

  useEffect(() => { document.title = search ? `Search · ${search} · hopNshop` : 'hopNshop — curated, sourced, yours'; }, [search]);

  return <IonApp><IonPage><IonContent fullscreen>
    <header className="topbar"><button className="icon-button mobile-only" onClick={() => setMenuOpen(v => !v)} aria-label="Open navigation"><IonIcon icon={menuOutline} /></button><a className="wordmark" href="#top" aria-label="hopNshop home"><span>hop</span><b>N</b><span>shop</span></a><nav className={menuOpen ? 'nav open' : 'nav'}>{nav.map(item => <a href={item === 'Source a product' ? '#source' : '#discover'} key={item} onClick={() => setMenuOpen(false)}>{item}</a>)}</nav><div className="top-actions"><label className="search"><IonIcon icon={searchOutline} /><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search curated finds" aria-label="Search products" /></label><button className="icon-button" aria-label="Wishlist"><IonIcon icon={heartOutline} /></button><button className="icon-button" aria-label="Cart"><IonIcon icon={bagHandleOutline} /></button></div></header>
    <main id="top">
      <section className="hero"><div className="hero-copy"><p className="eyebrow">Curated commerce · Kenya</p><h1>Find the things<br /><em>worth bringing home.</em></h1><p className="hero-lede">A considered edit of products from trusted sources — plus a human team for the things you cannot find locally.</p><div className="hero-actions"><a className="button button-dark" href="#discover">Explore the edit <IonIcon icon={arrowForwardOutline} /></a><button className="text-button" onClick={() => setSourcingOpen(true)}>Need something specific? <u>Ask us to source it</u></button></div></div><div className="hero-art"><div className="sun"></div><div className="art-card"><span className="art-label">THE HOP EDIT · 01</span><div className="art-object">✦</div><p>Small finds.<br />Big delight.</p></div><span className="scribble">good things<br />take a little<br />hopping</span></div></section>
      <section className="trust-strip"><div><IonIcon icon={shieldCheckmarkOutline} /><span>Curated with care</span></div><div><IonIcon icon={sparklesOutline} /><span>Transparent sourcing</span></div><div><IonIcon icon={heartOutline} /><span>Made for your life</span></div></section>
      <section className="section" id="discover"><div className="section-heading"><div><p className="eyebrow">The edit</p><h2>Good things, <em>in season.</em></h2></div><p className="muted">Freshly reviewed finds, approved sources and a little bit of serendipity.</p></div>{filtered.length ? <div className="product-grid">{filtered.map(p => <article className="product-card" key={p.id}><div className="product-image">{p.imageUrl ? <img src={p.imageUrl} alt="" /> : '✦'}</div><p className="eyebrow">{p.category ?? p.availability}</p><h3>{p.name}</h3><p>{p.description}</p></article>)}</div> : <div className="empty-state"><div className="empty-mark">✦</div><h3>The shelves are being set.</h3><p>Our team is reviewing the next edit. In the meantime, tell us what you are looking for and we will help you find it.</p><button className="button button-dark" onClick={() => setSourcingOpen(true)}>Request a product <IonIcon icon={arrowForwardOutline} /></button></div>}</section>
      <section className="source-band" id="source"><div><p className="eyebrow">The sourcing desk</p><h2>Some things are<br /><em>worth the search.</em></h2><p>Send us a product link from a supported marketplace. We will check the source, work out an estimated landed cost and send you a clear quotation before anything is ordered.</p><button className="button button-light" onClick={() => setSourcingOpen(true)}>Start a sourcing request <IonIcon icon={arrowForwardOutline} /></button></div><div className="source-stamp">SOURCE<br /><b>WITH</b><br />CONFIDENCE</div></section>
      <section className="footer-cta"><p className="eyebrow">Keep in the loop</p><h2>Good finds, <em>occasionally.</em></h2><p>New edits, sourcing notes and useful guides. No noise.</p><form onSubmit={e => e.preventDefault()}><input type="email" required placeholder="Your email address" aria-label="Email address" /><button className="button button-dark" type="submit">Join the list</button></form><small>{isSupabaseConfigured ? 'Connected to your Supabase project.' : 'Newsletter delivery activates when Supabase and an email provider are configured.'}</small></section>
    </main>
    {sourcingOpen && <div className="modal-backdrop" role="presentation" onClick={() => setSourcingOpen(false)}><div className="modal" role="dialog" aria-modal="true" aria-labelledby="source-title" onClick={e => e.stopPropagation()}><button className="modal-close" onClick={() => setSourcingOpen(false)} aria-label="Close">×</button><p className="eyebrow">The sourcing desk</p><h2 id="source-title">What are you looking for?</h2><p>Share a link and our team will review it. No payment is taken at this stage.</p><form onSubmit={e => { e.preventDefault(); setSourcingOpen(false); alert('Request saved locally. Connect Supabase to submit it securely.'); }}><input required type="url" placeholder="https://… product link" aria-label="Product URL" /><input type="number" min="1" defaultValue="1" aria-label="Quantity" /><textarea placeholder="Size, colour or anything else we should know" aria-label="Product notes" /><button className="button button-dark" type="submit">Submit request <IonIcon icon={arrowForwardOutline} /></button></form></div></div>}
    <footer><span className="wordmark"><span>hop</span><b>N</b><span>shop</span></span><span>© {new Date().getFullYear()} hopNshop</span><span>Affiliate disclosure · Privacy · Terms</span></footer>
  </IonContent></IonPage></IonApp>;
}

export default App;
