# Security checklist

- Supabase RLS is enabled for private user data; validate it with separate customer accounts before launch.
- Never expose service-role, Daraja or provider secrets in Vite environment variables or Git.
- Only accept HTTPS public source URLs; do not fetch arbitrary URLs from the browser or server without an approved adapter.
- Validate file type, size and ownership before Storage uploads; use private buckets for request media.
- Treat payment callbacks as untrusted input, persist idempotency keys, and require admin verification.
- Log privileged changes in `admin_audit_logs` without storing unnecessary personal data.
- Configure rate limits, CAPTCHA/abuse controls, backups, retention and incident response before public launch.
- Have Kenya Data Protection Act, consumer, tax, import and payment documents reviewed by qualified professionals; this repository makes no legal-certification claim.
