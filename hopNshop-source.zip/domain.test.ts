import { calculateQuote, canTransitionOrder, isValidPublicProductUrl } from '../src/lib/domain';

describe('quote calculation', () => {
  it('adds costs and applies markup and discount', () => {
    expect(calculateQuote({ lines: [{ description: 'Item', quantity: 2, unitAmount: 100 }], shipping: 50, duties: 20, taxes: 10, serviceFee: 25, markupRate: .1, discount: 10 })).toEqual({ subtotal: 405, markup: 40.5, total: 435.5 });
  });
});
describe('safe source URLs', () => {
  it('rejects private networks and accepts public HTTPS URLs', () => { expect(isValidPublicProductUrl('http://localhost:3000/x')).toBe(false); expect(isValidPublicProductUrl('https://192.168.0.1/x')).toBe(false); expect(isValidPublicProductUrl('https://example.com/product')).toBe(true); });
});
describe('order transitions', () => {
  it('only permits the next workflow state or controlled exceptions', () => { expect(canTransitionOrder('awaiting_payment', 'payment_verification')).toBe(true); expect(canTransitionOrder('awaiting_payment', 'delivered')).toBe(false); expect(canTransitionOrder('delivered', 'cancelled')).toBe(false); expect(canTransitionOrder('payment_confirmed', 'refund_pending')).toBe(true); });
});
